import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  num = "";

  constructor() {}

  sete(){
    this.num = this.num + "7";

  }
  oito(){
    this.num = this.num + "7";

  }
  nove(){
    this.num = this.num + "7";

  }
  barra(){
    this.num = this.num + "7";

  }
  quatro(){
    this.num = this.num + "7";

  }
  cinco(){
    this.num = this.num + "7";

  }
  seis(){
    this.num = this.num + "7";

  }
  asterisco(){
    this.num = this.num + "7";

  }
  um(){
    this.num = this.num + "7";

  }


}
